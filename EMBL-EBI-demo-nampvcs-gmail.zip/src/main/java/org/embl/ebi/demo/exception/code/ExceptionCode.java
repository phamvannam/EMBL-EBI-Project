package org.embl.ebi.demo.exception.code;

public interface ExceptionCode {
  public String getMessageTemplate();

  public String getCode();
}
